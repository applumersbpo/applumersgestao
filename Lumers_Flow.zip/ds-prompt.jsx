// ds-prompt.jsx — handoff: CSS tokens + ready-to-paste prompt for Claude/dev

const TOKEN_CSS = `:root {
  /* ── Cores da marca Lumers ──────────────────────────────── */
  --brand-forest:    #3A5A40;
  --brand-sage:      #A2AF8B;
  --brand-teal:      #165D62;
  --brand-teal-soft: #669A8C;
  --brand-cream:     #EFE9D1;
  --brand-mustard:   #D4A24C;

  /* Escala primária (forest) */
  --primary-50:  #F1F5EE; --primary-100: #DDE7D8; --primary-200: #BACDB1;
  --primary-300: #94B189; --primary-400: #6E9163; --primary-500: #4D7549;
  --primary-600: #3A5A40; --primary-700: #2C4630; --primary-800: #1E3322;
  --primary-900: #132018;

  /* Neutros quentes */
  --neutral-0:   #FFFFFF; --neutral-50:  #FBF9F2; --neutral-100: #F4F1E6;
  --neutral-200: #E8E2D0; --neutral-300: #D6CFBA; --neutral-400: #ADA897;
  --neutral-500: #807B6C; --neutral-600: #5D594E; --neutral-700: #403D35;
  --neutral-800: #292720; --neutral-900: #1A1813;

  /* Semânticos suavizados */
  --income-700:  #2C4630; --income-600:  #3A5A40; --income-500:  #4D7549;
  --income-100:  #DDE7D8; --income-50:   #F1F5EE;

  --expense-700: #8E3A30; --expense-600: #B14939; --expense-500: #C95A47;
  --expense-100: #F4DCD4; --expense-50:  #FAEDE7;

  --warn-700:    #8A6418; --warn-600:    #C28A2A; --warn-500:    #D4A24C;
  --warn-100:    #F5E4BD; --warn-50:     #FAF1D8;

  --info-700:    #0E4549; --info-600:    #165D62; --info-500:    #2A7C82;
  --info-100:    #C8DDDF; --info-50:     #E4EFF0;

  /* Superfícies, textos */
  --bg: var(--neutral-50);    --bg-elevated: var(--neutral-0);
  --bg-subtle: var(--neutral-100); --bg-canvas: #F6F2E6;
  --border: var(--neutral-200); --border-strong: var(--neutral-300);
  --text: var(--neutral-800); --text-muted: var(--neutral-600); --text-soft: var(--neutral-500);
  --text-on-primary: #F8F4E4;

  /* Sidebar */
  --sidebar-bg: var(--primary-700);
  --sidebar-text: #E6E0CC;
  --sidebar-text-muted: #B6BFA4;
  --sidebar-item-active-bg: rgba(248, 244, 228, .12);
  --sidebar-item-active-text: #F8F4E4;
  --sidebar-accent: var(--brand-mustard);

  /* Tipografia */
  --font-display: 'Spectral', Georgia, serif;
  --font-sans:    'Onest', ui-sans-serif, system-ui, sans-serif;
  --font-mono:    'JetBrains Mono', ui-monospace, monospace;

  /* Raios, sombras, espaços */
  --r-sm: 6px; --r-md: 10px; --r-lg: 14px; --r-xl: 20px; --r-pill: 999px;
  --sh-xs: 0 1px 2px rgba(41,39,32,.04);
  --sh-sm: 0 1px 2px rgba(41,39,32,.04), 0 1px 3px rgba(41,39,32,.06);
  --sh-md: 0 2px 4px rgba(41,39,32,.04), 0 4px 12px rgba(41,39,32,.06);
  --sh-lg: 0 4px 8px rgba(41,39,32,.04), 0 12px 28px rgba(41,39,32,.08);
}`;

const HANDOFF_PROMPT = `Refaça o design e as cores do Lumers Flow seguindo o Design System abaixo.

CONTEXTO
- Produto: SaaS de gestão financeira (BPO) para pequenas empresas.
- Marca: Lumers — acolhedora, acessível, descomplicada, facilitadora.
- Identidade visual usa verde-floresta + creme + acentos teal/mostarda.

DIRETRIZES GERAIS
1. Substitua a tipografia por Spectral (display/serif) + Onest (UI/sans).
   Importe via Google Fonts. Use Spectral para títulos de página, KPI values
   e quebras editoriais; Onest para todo o resto.
2. Aplique a paleta abaixo via CSS custom properties. NUNCA hard-code cores
   nos componentes — use sempre os tokens (--primary-*, --income-*, etc.).
3. Substitua o vermelho saturado e o verde-esmeralda atuais pelos tons
   semânticos suavizados (--expense-* terroso, --income-* verde da marca).
4. Sidebar passa a usar --primary-700 (verde escuro) com texto creme,
   item ativo com barra mostarda à esquerda. NÃO use a sage --sidebar antigo.
5. Cards: borda 1px var(--border), raio --r-lg, sombra --sh-xs (sutil).
   Padding generoso (20–24px). NUNCA borda colorida grossa à esquerda.
6. Botões: primário = --primary-700 / texto creme. Acento/CTA principal =
   --brand-mustard / texto --primary-900. Secundário = branco / borda neutra.
7. Inputs: borda var(--border-strong), foco com anel rgba(58,90,64,.15).
8. Valores monetários: Spectral 500, font-variant-numeric: tabular-nums.
   Receitas em var(--income-700), despesas em var(--expense-700).
9. Status badges: pílula --r-pill com fundo *--50, texto *--700, ponto em
   currentColor. Use os 4 tons: income, expense, warn, info.
10. Empty states e cards informativos devem explicar antes de exigir ação.
    Tom de voz: conciso, em português, sem jargão técnico.

TELAS A REDESENHAR
- Login (split-screen: lado esquerdo verde com manifesto + features, direito
  formulário em fundo claro).
- Dashboard (4 KPIs no topo: faturamento, contas a pagar, saldo projetado,
  saldo real; bloco grande de cobertura de despesas; gráfico de fluxo de
  caixa 12m; donut de categorias; lista de últimas movimentações; meta e
  alertas no aside).
- Contas a pagar (KPIs no topo, filtros pill, tabela densa com checkbox,
  status badges, valor à direita).
- Demais telas (Gastos do Dia, Faturamento, Metas, Categorias, etc.)
  herdam os mesmos padrões: header com título Spectral + sub Onest +
  ações à direita; conteúdo em grid de 12 com aside opcional.

NÃO FAÇA
- Não use Inter, Roboto ou Fraunces.
- Não use vermelho vivo (#EF4444) nem verde-esmeralda saturado (#10B981).
- Não use gradientes pesados — apenas radiais sutis em hero/login.
- Não use ícones com fill sólido. Apenas stroke 1.6, rounded, geométricos.
- Não invente cores fora dos tokens.

REFERÊNCIA COMPLETA: ver Lumers Flow Design System.html`;

function PromptSection() {
  const [copied, setCopied] = React.useState('');
  const copy = (txt, label) => {
    navigator.clipboard.writeText(txt);
    setCopied(label);
    setTimeout(() => setCopied(''), 1800);
  };

  return (
    <section id="handoff">
      <div className="shell">
        <div className="sec-label">07 · Handoff</div>
        <h2>Cole isso no Claude e parta pro código.</h2>
        <p className="sec-intro">
          Dois blocos prontos: os <b>tokens em CSS</b> (cole no <code>:root</code> do projeto)
          e o <b>prompt de implementação</b> com diretrizes objetivas pra refazer o painel.
          Mantenha este documento como referência viva.
        </p>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 28 }}>

          <div>
            <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 12 }}>
              <h3 style={{ fontSize: 19, fontWeight: 500 }}>Tokens CSS — cole no <code>:root</code></h3>
              <button className="btn btn-secondary sm" onClick={() => copy(TOKEN_CSS, 'tokens')}>
                {copied === 'tokens' ? <><Icons.Check size={13}/> Copiado!</> : <><Icons.Download size={13}/> Copiar</>}
              </button>
            </div>
            <div className="codeblock" style={{ maxHeight: 400 }}>
              {highlightCSS(TOKEN_CSS)}
            </div>
          </div>

          <div>
            <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 12 }}>
              <h3 style={{ fontSize: 19, fontWeight: 500 }}>Prompt para o Claude (ou dev)</h3>
              <button className="btn btn-secondary sm" onClick={() => copy(HANDOFF_PROMPT, 'prompt')}>
                {copied === 'prompt' ? <><Icons.Check size={13}/> Copiado!</> : <><Icons.Download size={13}/> Copiar</>}
              </button>
            </div>
            <div className="codeblock" style={{
              whiteSpace: 'pre-wrap', fontFamily: 'var(--font-sans)', fontSize: 13.5,
              background: 'var(--neutral-800)', lineHeight: 1.7
            }}>{HANDOFF_PROMPT}</div>
          </div>

          <div className="card canvas">
            <div className="grid cols-3">
              <div>
                <div className="label-mini">Fonte</div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, marginTop: 6 }}>Google Fonts</div>
                <code style={{ fontSize: 11, color: 'var(--text-muted)' }}>family=Onest:wght@300..700&family=Spectral:wght@300..600</code>
              </div>
              <div>
                <div className="label-mini">Reset</div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, marginTop: 6 }}>Tailwind, vanilla CSS ou stitches</div>
                <span style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>Os tokens são neutros — usam apenas custom properties.</span>
              </div>
              <div>
                <div className="label-mini">Acessibilidade</div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, marginTop: 6 }}>WCAG AA em todos os pares</div>
                <span style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>text/bg passam em ≥4.5:1. Foco visível com --sh-focus.</span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}

function highlightCSS(src) {
  const lines = src.split('\n');
  return lines.map((line, i) => {
    if (line.trim().startsWith('/*')) {
      return <div key={i}><span className="com">{line}</span></div>;
    }
    const m = line.match(/^(\s*)(--[\w-]+):\s*(.+?);(.*)$/);
    if (m) {
      return (
        <div key={i}>
          {m[1]}<span className="key">{m[2]}</span>: <span className="str">{m[3]}</span>;
          {m[4] && <span className="com">{m[4]}</span>}
        </div>
      );
    }
    return <div key={i}>{line}</div>;
  });
}

Object.assign(window, { PromptSection });
