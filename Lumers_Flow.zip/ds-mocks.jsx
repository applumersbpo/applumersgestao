// ds-mocks.jsx — Redesigned Dashboard and Login mockups, applying the design system

function MocksSection() {
  const [tab, setTab] = React.useState('dashboard');
  return (
    <section id="mocks">
      <div className="shell">
        <div className="sec-label">06 · Aplicado</div>
        <h2>O sistema, vivendo no produto.</h2>
        <p className="sec-intro">
          Mesma informação do painel atual, redesenhada com o novo sistema. Veja como hierarquia,
          cor e ritmo trabalham juntos pra reduzir ruído sem perder densidade.
        </p>

        <div style={{ display: 'inline-flex', padding: 4, background: 'var(--neutral-100)', borderRadius: 12, marginBottom: 24 }}>
          {[
            { id: 'dashboard', label: 'Dashboard' },
            { id: 'contas',    label: 'Contas a pagar' },
            { id: 'login',     label: 'Login' },
          ].map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className="btn sm"
              style={{
                background: tab === t.id ? 'var(--bg-elevated)' : 'transparent',
                color: tab === t.id ? 'var(--primary-800)' : 'var(--text-muted)',
                border: 'none',
                boxShadow: tab === t.id ? 'var(--sh-xs)' : 'none',
              }}>{t.label}</button>
          ))}
        </div>

        <div className="mock-frame">
          <div className="browser-bar">
            <div className="dots"><span/><span/><span/></div>
            <div className="url">app.lumersflow.com.br/{tab === 'login' ? 'entrar' : tab}</div>
          </div>
          {tab === 'dashboard' && <DashboardMock />}
          {tab === 'contas'    && <ContasMock />}
          {tab === 'login'     && <LoginMock />}
        </div>
      </div>
    </section>
  );
}

/* ─── Sidebar ─────────────────────────────────────────────────────── */
function Sidebar({ active = 'Dashboard' }) {
  const items = [
    { label: 'Dashboard',    icon: <Icons.Dashboard /> },
    { label: 'Contas a Pagar', icon: <Icons.Invoice /> },
    { label: 'Gastos do Dia',  icon: <Icons.Sun /> },
    { label: 'Gastos Gerais',  icon: <Icons.Wallet /> },
    { label: 'Faturamento',    icon: <Icons.TrendUp /> },
    { label: 'Categorias',     icon: <Icons.Tag /> },
    { label: 'Recorrências',   icon: <Icons.Repeat /> },
    { label: 'Parcelamentos',  icon: <Icons.Layers /> },
    { label: 'Metas',          icon: <Icons.Target /> },
    { label: 'Relatórios',     icon: <Icons.Chart /> },
    { label: 'Importar',       icon: <Icons.Upload /> },
  ];
  const admin = [
    { label: 'Configurações', icon: <Icons.Settings /> },
    { label: 'Usuários',      icon: <Icons.Users /> },
  ];
  return (
    <aside className="sidebar">
      <div className="logo">Lumers</div>

      <div className="section-label">Operação</div>
      {items.map(it => (
        <div key={it.label} className={"nav-item " + (it.label === active ? 'active' : '')}>
          {it.icon}<span>{it.label}</span>
        </div>
      ))}

      <div className="section-label">Administração</div>
      {admin.map(it => (
        <div key={it.label} className={"nav-item " + (it.label === active ? 'active' : '')}>
          {it.icon}<span>{it.label}</span>
        </div>
      ))}

      <div className="footer">
        <div className="avatar">A</div>
        <div className="who"><b>Ana Mendes</b><span>Admin · Lumers</span></div>
        <Icons.Logout size={15} style={{ color: 'var(--sidebar-text-muted)', cursor: 'pointer' }} />
      </div>
    </aside>
  );
}

/* ─── Dashboard mock ──────────────────────────────────────────────── */
function DashboardMock() {
  return (
    <div className="app">
      <Sidebar active="Dashboard" />
      <div className="main">
        <div className="app-header">
          <div>
            <div className="title">Bom dia, Ana.</div>
            <div className="sub">Visão geral — Maio de 2026, 24 dias decorridos</div>
          </div>
          <div className="actions">
            <button className="btn btn-secondary sm"><Icons.Filter size={13} /> Filtros</button>
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '4px 4px 4px 14px', border: '1px solid var(--border)', borderRadius: 10, background: 'var(--bg-elevated)' }}>
              <Icons.ChevronL size={14} style={{ color: 'var(--text-muted)', cursor: 'pointer' }} />
              <span style={{ fontSize: 13, fontWeight: 500, padding: '0 8px' }}>Maio 2026</span>
              <Icons.ChevronR size={14} style={{ color: 'var(--text-muted)', cursor: 'pointer' }} />
            </div>
            <button className="btn btn-accent"><Icons.Plus size={14} /> Lançar</button>
          </div>
        </div>

        <div style={{ padding: '28px 32px', display: 'flex', flexDirection: 'column', gap: 24 }}>

          {/* KPIs */}
          <div className="grid cols-4">
            <Kpi tone="income"  label="Faturamento"     value="R$ 48.320" delta="+12% vs. mês passado" deltaTone="income"
                 icon={<Icons.TrendUp />} progress={69} progressLabel="69% da meta · R$ 70.000" />
            <Kpi tone="expense" label="Contas a pagar"  value="R$ 22.180" delta="R$ 8.4k vencendo em 7 dias" deltaTone="warn"
                 icon={<Icons.TrendDown />} progress={62} progressTone="expense" progressLabel="62% pago" />
            <Kpi tone="info"    label="Saldo projetado" value="R$ 26.140" delta="Receita prevista − todas as saídas"
                 icon={<Icons.Wallet />} sparkData={[5,7,6,8,9,11,10,12,13,14]} />
            <Kpi tone="warn"    label="Saldo real"      value="R$ 18.700" delta="Recebido − o que saiu de fato"
                 icon={<Icons.Sun />} />
          </div>

          {/* Cobertura + Insight */}
          <div className="grid cols-2" style={{ gridTemplateColumns: '1.6fr 1fr' }}>
            <div className="card" style={{ padding: 26 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                <div>
                  <div className="label-mini">Cobertura de despesas</div>
                  <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 26, fontWeight: 500, marginTop: 6 }}>Sua receita cobre <em style={{ color: 'var(--income-700)', fontStyle: 'italic' }}>218%</em> do que sai.</h3>
                  <p style={{ fontSize: 13.5, color: 'var(--text-muted)', marginTop: 6 }}>Sobram R$ 26.140 do que entrou em maio depois das saídas. Mantenha pelo menos 1,5× pra absorver imprevistos.</p>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: 44, fontWeight: 500, lineHeight: 1, color: 'var(--income-700)' }}>218%</div>
                  <div style={{ fontSize: 11.5, color: 'var(--text-soft)', marginTop: 4 }}>do total coberto</div>
                </div>
              </div>
              <div style={{ marginTop: 22, height: 10, background: 'var(--neutral-100)', borderRadius: 999, position: 'relative', overflow: 'visible' }}>
                <div style={{ position: 'absolute', inset: '0 0 0 0', width: '46%', background: 'var(--expense-500)', borderRadius: 999, opacity: .8 }} />
                <div style={{ position: 'absolute', left: 'calc(46% - 1px)', top: -4, bottom: -4, width: 2, background: 'var(--primary-800)', borderRadius: 2 }} />
                <div style={{ position: 'absolute', left: 'calc(46% + 6px)', top: -22, fontSize: 10, color: 'var(--text-soft)', fontFamily: 'var(--font-mono)' }}>break-even</div>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 12, fontSize: 12 }}>
                <span style={{ color: 'var(--text-muted)' }}>Compromissos: <b style={{ color: 'var(--expense-700)', fontFamily: 'var(--font-display)' }}>R$ 22.180</b></span>
                <span style={{ color: 'var(--text-muted)' }}>Faturamento: <b style={{ color: 'var(--income-700)', fontFamily: 'var(--font-display)' }}>R$ 48.320</b></span>
              </div>
            </div>

            <div className="insight income">
              <div className="ico-tile"><Icons.Sparkle size={16} /></div>
              <div className="body">
                <b>Você está 12% acima da meta.</b>
                <p>No ritmo atual, fecha maio em R$ 52.400. Continue a régua de cobrança aberta para 3 clientes em atraso.</p>
                <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
                  <button className="btn btn-primary sm">Ver clientes em atraso</button>
                  <button className="btn btn-ghost sm">Dispensar</button>
                </div>
              </div>
            </div>
          </div>

          {/* Cashflow + categorias */}
          <div className="grid cols-2" style={{ gridTemplateColumns: '1.6fr 1fr' }}>
            <div className="card" style={{ padding: 26 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 4 }}>
                <div>
                  <div className="label-mini">Fluxo de caixa</div>
                  <h4 style={{ fontFamily: 'var(--font-display)', fontSize: 19, fontWeight: 500, marginTop: 4 }}>Últimos 12 meses</h4>
                </div>
                <div style={{ display: 'flex', gap: 14, fontSize: 11.5, color: 'var(--text-muted)' }}>
                  <span style={{ display:'flex', alignItems:'center', gap:6 }}><span style={{ width:10, height:10, background:'var(--primary-600)', borderRadius:2 }}/>Receita</span>
                  <span style={{ display:'flex', alignItems:'center', gap:6 }}><span style={{ width:10, height:10, background:'var(--expense-500)', borderRadius:2, opacity:.7 }}/>Despesa</span>
                </div>
              </div>
              <CashflowChart />
            </div>
            <div className="card" style={{ padding: 26 }}>
              <div className="label-mini">Para onde foi o dinheiro</div>
              <h4 style={{ fontFamily: 'var(--font-display)', fontSize: 19, fontWeight: 500, marginTop: 4 }}>Maio · por categoria</h4>
              <CategoryDonut />
            </div>
          </div>

          {/* Movimentações */}
          <div className="grid cols-2" style={{ gridTemplateColumns: '1.6fr 1fr' }}>
            <div className="card" style={{ padding: 0 }}>
              <div style={{ padding: '18px 22px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid var(--border)' }}>
                <div>
                  <div className="label-mini">Movimentações</div>
                  <h4 style={{ fontFamily: 'var(--font-display)', fontSize: 19, fontWeight: 500, marginTop: 4 }}>Últimos 5 lançamentos</h4>
                </div>
                <a href="#" style={{ fontSize: 12.5, color: 'var(--primary-700)' }}>Ver tudo →</a>
              </div>
              <Row tone="income"  who="Studio Pílula"   sub="Recebido · 24/05"     badge={{tone:'income',  text:'Pago'}}      amount="+ R$ 2.480,00" amountTone="income" />
              <Row tone="expense" who="Aluguel · Maio"  sub="Vence em 3 dias"      badge={{tone:'warn',    text:'A vencer'}}  amount="− R$ 3.200,00" amountTone="expense" />
              <Row tone="info"    who="Notion · Plano"  sub="Recorrente · 28/05"   badge={{tone:'info',    text:'Recorrente'}} amount="− R$ 96,00"    amountTone="expense" />
              <Row tone="expense" who="Tipograf Brasil" sub="Atrasado há 2 dias"   badge={{tone:'expense', text:'Atrasado'}}  amount="− R$ 540,00"   amountTone="expense" />
              <Row tone="income"  who="Casa Verão"      sub="Recebido · 22/05"     badge={{tone:'income',  text:'Pago'}}      amount="+ R$ 1.250,00" amountTone="income" />
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div className="card" style={{ padding: 22 }}>
                <div className="label-mini">Meta de faturamento</div>
                <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginTop: 8, marginBottom: 12 }}>
                  <span style={{ fontFamily: 'var(--font-display)', fontSize: 30, fontWeight: 500 }}>R$ 48.320</span>
                  <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>de R$ 70.000</span>
                </div>
                <div className="progress income"><span style={{ width: '69%' }}/></div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 10, fontSize: 12, color: 'var(--text-soft)' }}>
                  <span>69% concluído</span><span>7 dias úteis restantes</span>
                </div>
              </div>
              <div className="insight">
                <div className="ico-tile"><Icons.Bell size={16} /></div>
                <div className="body">
                  <b>3 contas vencem nos próximos 5 dias.</b>
                  <p>Total de R$ 8.420,00. <a href="#">Programar pagamentos →</a></p>
                </div>
              </div>
              <div className="card" style={{ padding: 22, background: 'var(--bg-canvas)', border: 'none' }}>
                <div className="label-mini" style={{ color: 'var(--primary-700)' }}>Dica do mês</div>
                <p style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 18, lineHeight: 1.35, marginTop: 8, color: 'var(--neutral-800)' }}>
                  "Fature mais. Gaste menos. Invista sempre."
                </p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

/* ─── Contas a pagar mock ─────────────────────────────────────────── */
function ContasMock() {
  const rows = [
    { who: 'Aluguel sala comercial', cat: 'Infraestrutura', due: '28/05', val: 3200, status: 'warn',    statusLabel: 'Vence em 3 dias' },
    { who: 'Tipograf Brasil',        cat: 'Fornecedores',    due: '22/05', val: 540,  status: 'expense', statusLabel: 'Atrasado · 2d' },
    { who: 'Notion · Time plan',     cat: 'Software',        due: '28/05', val: 96,   status: 'info',    statusLabel: 'Recorrente' },
    { who: 'Folha · Equipe maio',    cat: 'Folha',           due: '05/06', val: 14800,status: 'warn',    statusLabel: 'A vencer' },
    { who: 'Energia · Cemig',        cat: 'Infraestrutura', due: '02/06', val: 312,  status: 'warn',    statusLabel: 'A vencer' },
    { who: 'Stripe · Taxas abril',   cat: 'Banco',           due: '15/05', val: 184,  status: 'income',  statusLabel: 'Pago' },
    { who: 'Google Workspace',       cat: 'Software',        due: '20/05', val: 89,   status: 'income',  statusLabel: 'Pago' },
    { who: 'Contabilidade · Vox',    cat: 'Serviços',        due: '10/06', val: 680,  status: 'warn',    statusLabel: 'A vencer' },
  ];
  const total = rows.reduce((s,r) => s + r.val, 0);
  const paid  = rows.filter(r => r.status === 'income').reduce((s,r) => s + r.val, 0);
  const overdue = rows.filter(r => r.status === 'expense').reduce((s,r) => s + r.val, 0);

  return (
    <div className="app">
      <Sidebar active="Contas a Pagar" />
      <div className="main">
        <div className="app-header">
          <div>
            <div className="title">Contas a pagar</div>
            <div className="sub">8 lançamentos em aberto · {fmt(total - paid)} a pagar</div>
          </div>
          <div className="actions">
            <button className="btn btn-secondary sm"><Icons.Search size={13} /> Buscar</button>
            <button className="btn btn-secondary sm"><Icons.Filter size={13} /> Filtros</button>
            <button className="btn btn-accent"><Icons.Plus size={14} /> Nova conta</button>
          </div>
        </div>

        <div style={{ padding: '28px 32px', display: 'flex', flexDirection: 'column', gap: 22 }}>
          <div className="grid cols-3">
            <Kpi tone="expense" label="Total a pagar"   value={fmt(total - paid)} icon={<Icons.Wallet />} delta={`${rows.length - rows.filter(r=>r.status==='income').length} lançamentos em aberto`} />
            <Kpi tone="warn"    label="Vence em 7 dias" value={fmt(rows.filter(r => r.status === 'warn').reduce((s,r)=>s+r.val,0))} icon={<Icons.Bell />} delta="Programar pagamento" />
            <Kpi tone="income"  label="Pago no mês"     value={fmt(paid)} icon={<Icons.Check />} delta={`${rows.filter(r=>r.status==='income').length} contas conciliadas`} />
          </div>

          <div className="card" style={{ padding: 0 }}>
            <div style={{ padding: '14px 22px', display: 'flex', alignItems: 'center', gap: 12, borderBottom: '1px solid var(--border)' }}>
              <div style={{ position: 'relative', flex: 1, maxWidth: 320 }}>
                <Icons.Search size={14} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-soft)' }} />
                <input className="input" placeholder="Buscar por fornecedor, categoria…" style={{ paddingLeft: 36, fontSize: 13 }} />
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                <button className="btn btn-secondary sm">Todas</button>
                <button className="btn btn-ghost sm" style={{ color: 'var(--warn-700)' }}>A vencer</button>
                <button className="btn btn-ghost sm" style={{ color: 'var(--expense-700)' }}>Atrasadas</button>
                <button className="btn btn-ghost sm">Pagas</button>
              </div>
              <div style={{ marginLeft: 'auto', display: 'flex', gap: 8, alignItems: 'center', fontSize: 12, color: 'var(--text-soft)' }}>
                <Icons.ChevronD size={14}/> Vencimento ↑
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '36px 1.6fr 1fr .8fr 1fr .8fr 24px', gap: 14, padding: '12px 22px', fontSize: 11, fontWeight: 600, color: 'var(--text-soft)', textTransform: 'uppercase', letterSpacing: '.1em', borderBottom: '1px solid var(--border)' }}>
              <span/>
              <span>Descrição</span>
              <span>Categoria</span>
              <span>Vencimento</span>
              <span>Status</span>
              <span style={{ textAlign: 'right' }}>Valor</span>
              <span/>
            </div>
            {rows.map((r, i) => (
              <div key={i} style={{ display: 'grid', gridTemplateColumns: '36px 1.6fr 1fr .8fr 1fr .8fr 24px', gap: 14, alignItems: 'center', padding: '14px 22px', borderBottom: i === rows.length - 1 ? 'none' : '1px solid var(--border)' }}>
                <input type="checkbox" style={{ accentColor: 'var(--primary-600)' }} />
                <div>
                  <b style={{ fontSize: 14 }}>{r.who}</b>
                  <div style={{ fontSize: 11.5, color: 'var(--text-soft)' }}>NF #{1240 + i}</div>
                </div>
                <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>{r.cat}</span>
                <span style={{ fontSize: 13, fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>{r.due}</span>
                <span className={"badge " + r.status}><span className="dot"/>{r.statusLabel}</span>
                <span style={{ textAlign: 'right', fontFamily: 'var(--font-display)', fontWeight: 500, fontSize: 15,
                              color: r.status === 'income' ? 'var(--income-700)' : 'var(--expense-700)' }}>
                  {fmt(r.val)}
                </span>
                <Icons.Grip size={14} style={{ color: 'var(--text-soft)' }} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function fmt(v) {
  return 'R$ ' + v.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

/* ─── Login mock ──────────────────────────────────────────────────── */
function LoginMock() {
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: '1.05fr 1fr', minHeight: 720,
      background: 'var(--bg)', fontFamily: 'var(--font-sans)'
    }}>
      <div style={{
        position: 'relative', overflow: 'hidden',
        background:
          'radial-gradient(800px 500px at 20% 20%, rgba(212,162,76,.22), transparent 60%),' +
          'radial-gradient(700px 500px at 80% 80%, rgba(102,154,140,.25), transparent 60%),' +
          'linear-gradient(180deg, var(--primary-700), var(--primary-800))',
        color: 'var(--text-on-primary)',
        padding: '64px 56px',
        display: 'flex', flexDirection: 'column'
      }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 500, position: 'relative', display: 'inline-block' }}>
          Lumers
          <span style={{ position: 'absolute', inset: '8% 16% 50% 4%', background: 'linear-gradient(160deg, rgba(212,162,76,.55), transparent 70%)', pointerEvents: 'none' }}/>
          <div style={{ fontFamily: 'var(--font-sans)', fontSize: 9.5, letterSpacing: '.24em', color: 'rgba(248,244,228,.6)', marginTop: -2 }}>BPO FINANCEIRO</div>
        </div>

        <div style={{ marginTop: 'auto' }}>
          <h2 style={{ color: 'var(--text-on-primary)', fontSize: 44, lineHeight: 1.1, fontWeight: 500, maxWidth: '14ch' }}>
            Visão clara sobre seu <em style={{ fontStyle: 'italic', color: 'var(--brand-mustard)' }}>fluxo financeiro</em>.
          </h2>
          <p style={{ marginTop: 18, fontSize: 16, lineHeight: 1.6, color: 'rgba(248,244,228,.78)', maxWidth: '40ch' }}>
            Lance receitas e despesas, acompanhe metas, e tome decisões com confiança —
            no ritmo de quem cuida do próprio negócio.
          </p>

          <div style={{ marginTop: 36, display: 'flex', gap: 14, flexWrap: 'wrap' }}>
            {[
              { ico: <Icons.TrendUp size={14} />, t: 'Fluxo de caixa em tempo real' },
              { ico: <Icons.Target size={14} />,  t: 'Metas mensais com nudge' },
              { ico: <Icons.Repeat size={14} />,  t: 'Recorrências automáticas' },
            ].map(f => (
              <div key={f.t} style={{
                display: 'flex', alignItems: 'center', gap: 8,
                padding: '8px 12px', borderRadius: 999,
                background: 'rgba(248,244,228,.08)', border: '1px solid rgba(248,244,228,.14)',
                fontSize: 12.5, color: 'rgba(248,244,228,.88)'
              }}>{f.ico} {f.t}</div>
            ))}
          </div>
        </div>
      </div>

      <div style={{ display: 'grid', placeItems: 'center', padding: 48 }}>
        <div style={{ width: '100%', maxWidth: 380 }}>
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 32, fontWeight: 500 }}>Entrar</h3>
          <p style={{ fontSize: 14, color: 'var(--text-muted)', marginTop: 8 }}>Bem-vinda de volta. Acesse seu painel.</p>

          <div style={{ marginTop: 28, display: 'flex', flexDirection: 'column', gap: 18 }}>
            <div className="field">
              <label>E-mail</label>
              <input className="input" defaultValue="ana@lumers.com.br" />
            </div>
            <div className="field">
              <label style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Senha</span>
                <a href="#" style={{ fontSize: 12 }}>Esqueci minha senha</a>
              </label>
              <div style={{ position: 'relative' }}>
                <input className="input" type="password" defaultValue="••••••••" style={{ paddingRight: 40 }} />
                <Icons.Eye size={16} style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-soft)', cursor: 'pointer' }} />
              </div>
            </div>
            <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: 'var(--text-muted)' }}>
              <input type="checkbox" defaultChecked style={{ accentColor: 'var(--primary-600)' }} />
              Manter conectado neste dispositivo
            </label>
            <button className="btn btn-primary lg" style={{ width: '100%' }}>Entrar no Lumers Flow</button>
            <div style={{ textAlign: 'center', fontSize: 13, color: 'var(--text-muted)' }}>
              Não tem conta? <a href="#" style={{ fontWeight: 500 }}>Criar conta</a>
            </div>
          </div>

          <div style={{ marginTop: 48, paddingTop: 22, borderTop: '1px solid var(--border)', fontSize: 11.5, color: 'var(--text-soft)', textAlign: 'center' }}>
            © 2026 Lumers BPO Financeiro · CNPJ 00.000.000/0001-00
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { MocksSection });
