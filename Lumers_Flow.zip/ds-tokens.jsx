// ds-tokens.jsx — sections: Foundations / Colors / Type / Spacing & Radii / Shadows

const TOKENS = JSON.parse(document.getElementById('lf-tokens').textContent);

function ColorChip({ name, hex, big = false }) {
  const dark = isDark(hex);
  return (
    <div className="swatch">
      <div className="chip" style={{ background: hex, height: big ? 132 : 96 }} />
      <div className="body">
        <span className="name">{name}</span>
        <span className="hex">{hex.toUpperCase()}</span>
      </div>
    </div>
  );
}

function isDark(hex) {
  const c = hex.replace('#','');
  const r = parseInt(c.slice(0,2),16), g = parseInt(c.slice(2,4),16), b = parseInt(c.slice(4,6),16);
  const l = (0.299*r + 0.587*g + 0.114*b);
  return l < 145;
}

function Ramp({ name, scale }) {
  const keys = Object.keys(scale);
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 10 }}>
        <div>
          <div className="label-mini">{name}</div>
          <code className="token-name">--{name.toLowerCase()}-50 … 900</code>
        </div>
      </div>
      <div className="swatch-row" style={{ gridTemplateColumns: `repeat(${keys.length}, 1fr)` }}>
        {keys.map(k => (
          <div key={k} className={"step " + (isDark(scale[k]) ? 'dark' : '')}
               style={{ background: scale[k] }}>{k}</div>
        ))}
      </div>
    </div>
  );
}

function FoundationSection() {
  return (
    <section id="foundation">
      <div className="shell">
        <div className="sec-label">01 · Fundação</div>
        <h2>Princípios que guiam cada pixel.</h2>
        <p className="sec-intro">
          A marca <i>Lumers</i> existe pra <b>iluminar o caminho financeiro</b> de pequenas empresas.
          O sistema visual é direto e quente, com a paleta verde-creme da identidade, espaço pra respirar
          e tipografia que mistura precisão sans com humanidade serifada.
        </p>

        <div className="grid cols-4">
          {[
            { label: 'Acolhedora',   text: 'Tons quentes em vez de cinzas frios. Cantos suaves. Sombras leves. Nada agride.' },
            { label: 'Acessível',    text: 'Hierarquia clara, contraste suficiente, hit-targets generosos. Linguagem direta.' },
            { label: 'Descomplicada',text: 'Um KPI por card. Um botão primário por tela. Estado vazio explica antes de exigir.' },
            { label: 'Facilitadora', text: 'O sistema antecipa: sugere a próxima ação, agrupa o relacionado, esconde o ruído.' },
          ].map(p => (
            <div className="card" key={p.label}>
              <div style={{ width: 28, height: 28, borderRadius: 10, background: 'var(--primary-50)',
                            color: 'var(--primary-700)', display: 'grid', placeItems: 'center', marginBottom: 14 }}>
                <Icons.Light size={16} />
              </div>
              <b style={{ fontSize: 15 }}>{p.label}</b>
              <p style={{ fontSize: 13.5, color: 'var(--text-muted)', marginTop: 6, lineHeight: 1.55 }}>{p.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ColorsSection() {
  return (
    <section id="colors">
      <div className="shell">
        <div className="sec-label">02 · Cores</div>
        <h2>A paleta da marca, traduzida em tokens.</h2>
        <p className="sec-intro">
          Cinco cores nascem da identidade: <b>verde-floresta</b>, <b>verde-sálvia</b>, <b>teal profundo</b>,
          <b> teal claro</b> e <b>creme</b>. Acrescentamos um <b>mostarda quente</b> como acento
          (substitui o "amarelo pastel" da IDV em UI). Cada uma vira uma escala de 10 passos
          para construir superfícies, textos e estados sem improvisar.
        </p>

        <div className="grid cols-6" style={{ marginBottom: 56 }}>
          <ColorChip name="Forest"      hex={TOKENS.brand.forest} big />
          <ColorChip name="Sage"        hex={TOKENS.brand.sage} big />
          <ColorChip name="Teal"        hex={TOKENS.brand.teal} big />
          <ColorChip name="Teal Soft"   hex={TOKENS.brand.tealSoft} big />
          <ColorChip name="Cream"       hex={TOKENS.brand.cream} big />
          <ColorChip name="Mustard"     hex={TOKENS.brand.mustard} big />
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 28, marginBottom: 56 }}>
          <Ramp name="Primary"  scale={TOKENS.primary} />
          <Ramp name="Neutral"  scale={TOKENS.neutral} />
        </div>

        <h3 style={{ fontSize: 22, marginBottom: 8 }}>Cores semânticas</h3>
        <p style={{ color: 'var(--text-muted)', fontSize: 14.5, maxWidth: '62ch', marginBottom: 28 }}>
          Suavizadas pra harmonizar com a paleta. O <b>vermelho</b> virou um terroso digno; o
          <b> verde de receita</b> usa o próprio verde da marca; o <b>alerta</b> usa o mostarda;
          <b> info</b> usa o teal.
        </p>
        <div className="grid cols-4">
          <SemanticCard label="Receita" tone="income"  desc="Entradas. Faturamento. Conquistas." />
          <SemanticCard label="Despesa" tone="expense" desc="Saídas. Contas a pagar. Atrasos." />
          <SemanticCard label="Alerta"  tone="warn"    desc="Prazos próximos, atenção do usuário." />
          <SemanticCard label="Info"    tone="info"    desc="Dicas, status neutros, links contextuais." />
        </div>
      </div>
    </section>
  );
}

function SemanticCard({ label, tone, desc }) {
  const sem = TOKENS.semantic[tone];
  return (
    <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', height: 56 }}>
        {['50','100','500','600','700'].map(step => (
          <div key={step} style={{ background: sem[step] }} />
        ))}
      </div>
      <div style={{ padding: '16px 18px 18px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
          <span className={"badge " + tone}><span className="dot" /> {label}</span>
        </div>
        <p style={{ fontSize: 13, color: 'var(--text-muted)', lineHeight: 1.5 }}>{desc}</p>
        <div style={{ marginTop: 12, display: 'flex', gap: 4, fontFamily: 'var(--font-mono)', fontSize: 10.5, color: 'var(--text-soft)', flexWrap: 'wrap' }}>
          <code>--{tone}-50</code><code>—</code><code>--{tone}-700</code>
        </div>
      </div>
    </div>
  );
}

function TypographySection() {
  const specs = [
    { tag: 'h1', sample: 'Fature mais. Gaste menos. Invista sempre.', font: 'display',
      size: 56, weight: 500, lh: 1.1,  use: 'Display — hero, abertura de tela' },
    { tag: 'h2', sample: 'Visão clara sobre seu mês.', font: 'display',
      size: 40, weight: 500, lh: 1.15, use: 'Page title' },
    { tag: 'h3', sample: 'Cobertura de despesas',     font: 'display',
      size: 22, weight: 500, lh: 1.25, use: 'Card title' },
    { tag: 'h4', sample: 'Últimas movimentações',     font: 'sans',
      size: 16, weight: 600, lh: 1.3,  use: 'Section heading' },
    { tag: 'p',  sample: 'Saldo projetado considera receitas previstas e todas as saídas confirmadas para o mês.',
      font: 'sans', size: 15, weight: 400, lh: 1.55, use: 'Body padrão' },
    { tag: 'small', sample: 'Vence em 3 dias · pago em 24/05',
      font: 'sans', size: 12.5, weight: 500, lh: 1.4, use: 'Metadados, footnotes' },
    { tag: 'eyebrow', sample: 'META DE FATURAMENTO',
      font: 'sans', size: 11, weight: 600, lh: 1.4, use: 'Eyebrow, label mini', tracking: '.18em', upper: true },
  ];

  return (
    <section id="typography">
      <div className="shell">
        <div className="sec-label">03 · Tipografia</div>
        <h2>Spectral + Onest — humanidade e precisão.</h2>
        <p className="sec-intro">
          A IDV original usa Brockmann (sans geométrica) e Coves (display fina). Como nenhuma é gratuita,
          substituímos por <b>Spectral</b> (serifada quente, com personalidade) para títulos e
          <b> Onest</b> (sans neutra e moderna) para UI — preservando a sensação acolhedora e técnica.
        </p>

        <div className="grid cols-2" style={{ marginBottom: 48 }}>
          <div className="card canvas">
            <div className="label-mini" style={{ marginBottom: 12 }}>Display · Spectral</div>
            <div style={{ fontFamily: "'Spectral', serif", fontSize: 88, lineHeight: 1, fontWeight: 500, letterSpacing: '-.02em' }}>Aa</div>
            <div style={{ fontFamily: "'Spectral', serif", fontSize: 18, marginTop: 8, color: 'var(--text-muted)' }}>
              ABCDEFGHIJKLMNOPQRSTUVWXYZ<br/>abcdefghijklmnopqrstuvwxyz 0123456789
            </div>
            <div style={{ marginTop: 12, fontSize: 12.5, color: 'var(--text-soft)' }}>
              Pesos: 300, 400, 500, 600 · itálico habilitado para ênfase suave em headlines
            </div>
          </div>
          <div className="card canvas">
            <div className="label-mini" style={{ marginBottom: 12 }}>UI · Onest</div>
            <div style={{ fontFamily: "'Onest', sans-serif", fontSize: 88, lineHeight: 1, fontWeight: 600, letterSpacing: '-.02em' }}>Aa</div>
            <div style={{ fontFamily: "'Onest', sans-serif", fontSize: 18, marginTop: 8, color: 'var(--text-muted)' }}>
              ABCDEFGHIJKLMNOPQRSTUVWXYZ<br/>abcdefghijklmnopqrstuvwxyz 0123456789
            </div>
            <div style={{ marginTop: 12, fontSize: 12.5, color: 'var(--text-soft)' }}>
              Pesos: 400, 500, 600, 700 · tabulares ativados em valores monetários
            </div>
          </div>
        </div>

        <div className="card">
          {specs.map((s, i) => (
            <div className="type-spec" key={i}>
              <div className="demo" style={{
                fontFamily: s.font === 'display' ? "var(--font-display)" : "var(--font-sans)",
                fontSize: s.size, lineHeight: s.lh, fontWeight: s.weight,
                letterSpacing: s.tracking || (s.size >= 28 ? '-.01em' : 0),
                textTransform: s.upper ? 'uppercase' : 'none',
                color: s.upper ? 'var(--text-soft)' : 'var(--text)'
              }}>
                {s.sample}
              </div>
              <div className="meta">
                <div><b>{s.use}</b></div>
                <div>{s.font === 'display' ? 'Spectral' : 'Onest'} · {s.size}px / {s.lh} · w{s.weight}</div>
                <div style={{ marginTop: 6 }}><code className="token-name">--fs-{s.tag}</code></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function SpacingSection() {
  const spaces = [
    { name: '1', px: 4 }, { name: '2', px: 8 }, { name: '3', px: 12 }, { name: '4', px: 16 },
    { name: '5', px: 20 }, { name: '6', px: 24 }, { name: '8', px: 32 }, { name: '10', px: 40 },
    { name: '12', px: 48 }, { name: '16', px: 64 },
  ];
  const radii = [
    { name: 'xs', px: 4, use: 'Tags inline' },
    { name: 'sm', px: 6, use: 'Botões pequenos' },
    { name: 'md', px: 10, use: 'Inputs, botões' },
    { name: 'lg', px: 14, use: 'Cards' },
    { name: 'xl', px: 20, use: 'Mocks de tela' },
    { name: 'pill', px: 999, use: 'Badges, progress' },
  ];
  const shadows = [
    { name: 'xs', use: 'Card neutro' },
    { name: 'sm', use: 'Inputs' },
    { name: 'md', use: 'Card hover, popover' },
    { name: 'lg', use: 'Modal, dropdown grande' },
  ];

  return (
    <section id="spacing">
      <div className="shell">
        <div className="sec-label">04 · Espaço, raio, sombra</div>
        <h2>Calibragens consistentes.</h2>
        <p className="sec-intro">
          Tudo cresce a partir de uma base de 4px. Raios discretos nos elementos pequenos e
          mais generosos nos containers principais — sombras quase invisíveis para preservar o tom acolhedor.
        </p>

        <h3 style={{ fontSize: 18, marginBottom: 14 }}>Espaçamento</h3>
        <div className="card" style={{ marginBottom: 40, padding: 28 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {spaces.map(s => (
              <div key={s.name} style={{ display: 'grid', gridTemplateColumns: '60px 80px 1fr', alignItems: 'center', gap: 16, fontSize: 13 }}>
                <code className="token-name">--space-{s.name}</code>
                <span style={{ color: 'var(--text-muted)' }}>{s.px}px</span>
                <span style={{ display: 'inline-block', height: 12, width: s.px, background: 'var(--primary-300)', borderRadius: 2 }} />
              </div>
            ))}
          </div>
        </div>

        <h3 style={{ fontSize: 18, marginBottom: 14 }}>Raios</h3>
        <div className="grid cols-6" style={{ marginBottom: 40 }}>
          {radii.map(r => (
            <div className="card" key={r.name} style={{ padding: 18, textAlign: 'left' }}>
              <div style={{ width: '100%', height: 64, background: 'var(--primary-100)', borderRadius: r.px, marginBottom: 14, border: '1px solid var(--primary-200)' }} />
              <code className="token-name">--r-{r.name}</code>
              <div style={{ fontSize: 12, color: 'var(--text-soft)', marginTop: 4 }}>{r.use}</div>
            </div>
          ))}
        </div>

        <h3 style={{ fontSize: 18, marginBottom: 14 }}>Sombras</h3>
        <div className="grid cols-4">
          {shadows.map(s => (
            <div key={s.name} style={{ background: 'var(--bg-canvas)', borderRadius: 14, padding: 24 }}>
              <div style={{ height: 92, background: 'var(--bg-elevated)', borderRadius: 12, boxShadow: `var(--sh-${s.name})` }} />
              <div style={{ marginTop: 14, fontSize: 13 }}><code className="token-name">--sh-{s.name}</code></div>
              <div style={{ fontSize: 12, color: 'var(--text-soft)', marginTop: 4 }}>{s.use}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

Object.assign(window, { FoundationSection, ColorsSection, TypographySection, SpacingSection });
