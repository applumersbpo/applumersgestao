// ds-app.jsx — main page shell + Tweaks panel

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "palette": "warm",
  "density": "regular",
  "displayFont": "Spectral",
  "sidebarStyle": "forest"
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // Map palette tweak to a class on body
  React.useEffect(() => {
    document.body.className = `density-${t.density} palette-${t.palette}`;
    // sidebar style override
    const root = document.documentElement;
    if (t.sidebarStyle === 'forest') {
      root.style.removeProperty('--sidebar-bg');
      root.style.removeProperty('--sidebar-text');
      root.style.removeProperty('--sidebar-text-muted');
      root.style.removeProperty('--sidebar-item-active-bg');
      root.style.removeProperty('--sidebar-item-active-text');
      root.style.removeProperty('--sidebar-item-hover-bg');
    } else if (t.sidebarStyle === 'sage') {
      root.style.setProperty('--sidebar-bg', '#A2AF8B');
      root.style.setProperty('--sidebar-text', '#1E3322');
      root.style.setProperty('--sidebar-text-muted', '#3A5A40');
      root.style.setProperty('--sidebar-item-active-bg', 'rgba(30, 51, 34, .14)');
      root.style.setProperty('--sidebar-item-active-text', '#132018');
      root.style.setProperty('--sidebar-item-hover-bg', 'rgba(30, 51, 34, .06)');
    } else if (t.sidebarStyle === 'clean') {
      root.style.setProperty('--sidebar-bg', '#FFFFFF');
      root.style.setProperty('--sidebar-text', '#1E3322');
      root.style.setProperty('--sidebar-text-muted', '#807B6C');
      root.style.setProperty('--sidebar-item-active-bg', '#F1F5EE');
      root.style.setProperty('--sidebar-item-active-text', '#2C4630');
      root.style.setProperty('--sidebar-item-hover-bg', '#FBF9F2');
    }
  }, [t.palette, t.density, t.sidebarStyle]);

  React.useEffect(() => {
    document.documentElement.style.setProperty('--font-display',
      t.displayFont === 'Spectral'   ? "'Spectral', Georgia, serif" :
      t.displayFont === 'Newsreader' ? "'Newsreader', Georgia, serif" :
      t.displayFont === 'Onest'      ? "'Onest', sans-serif" :
      "'Spectral', Georgia, serif"
    );
  }, [t.displayFont]);

  return (
    <>
      <header className="topbar">
        <div className="shell topbar-inner">
          <div className="brand-mark">
            <div className="lumers-logo">Lumers</div>
            <small>Design System v1</small>
          </div>
          <nav>
            <a href="#foundation">Fundação</a>
            <a href="#colors">Cores</a>
            <a href="#typography">Tipografia</a>
            <a href="#spacing">Espaço</a>
            <a href="#components">Componentes</a>
            <a href="#mocks">Aplicado</a>
            <a href="#handoff">Handoff</a>
          </nav>
        </div>
      </header>

      <div className="hero">
        <div className="shell">
          <span className="eyebrow"><Icons.Light size={11}/> Lumers Flow · BPO Financeiro</span>
          <h1>Iluminar o caminho, <em>com clareza e cuidado.</em></h1>
          <p className="lede">
            Um design system para o painel <b>Lumers Flow</b>, enraizado na identidade visual da marca:
            verde-floresta, sálvia e creme, costurados por uma tipografia que mistura
            humanidade serifada com precisão moderna. Use as próximas seções como guia para refazer o produto.
          </p>
          <div className="meta">
            <span><b>11</b> componentes-base</span>
            <span><b>40+</b> tokens semânticos</span>
            <span><b>3</b> telas-referência aplicadas</span>
            <span><b>Pronto pra</b> copy-paste no Claude</span>
          </div>
        </div>
      </div>

      <FoundationSection />
      <ColorsSection />
      <TypographySection />
      <SpacingSection />
      <ComponentsSection />
      <MocksSection />
      <PromptSection />

      <footer className="shell foot">
        <div>
          <b style={{ color: 'var(--text)' }}>Lumers Flow Design System</b> · v1.0 · 2026<br/>
          Fundado na identidade visual oficial Lumers BPO Financeiro.
        </div>
        <div style={{ textAlign: 'right' }}>
          <div>Fontes: <a href="https://fonts.google.com/specimen/Spectral" target="_blank" rel="noreferrer">Spectral</a> · <a href="https://fonts.google.com/specimen/Onest" target="_blank" rel="noreferrer">Onest</a></div>
          <div style={{ marginTop: 4 }}>Toggle de <b>Tweaks</b> no canto pra experimentar variações.</div>
        </div>
      </footer>

      <TweaksPanel title="Tweaks · Lumers Flow">
        <TweakSection label="Paleta de fundo" />
        <TweakRadio
          label="Temperatura"
          value={t.palette}
          options={['warm', 'clean']}
          onChange={(v) => setTweak('palette', v)}
        />
        <p style={{ fontSize: 11, color: 'var(--text-soft)', margin: '2px 4px 8px', lineHeight: 1.4 }}>
          <b>warm</b>: creme suave. <b>clean</b>: branco puro com acentos.
        </p>

        <TweakSection label="Sidebar" />
        <TweakSelect
          label="Estilo"
          value={t.sidebarStyle}
          options={['forest', 'sage', 'clean']}
          onChange={(v) => setTweak('sidebarStyle', v)}
        />
        <p style={{ fontSize: 11, color: 'var(--text-soft)', margin: '2px 4px 8px', lineHeight: 1.4 }}>
          <b>forest</b>: verde escuro com texto creme (recomendado).<br/>
          <b>sage</b>: verde-sálvia (atual).<br/>
          <b>clean</b>: branca, acentos verdes.
        </p>

        <TweakSection label="Densidade" />
        <TweakRadio
          label="Espaçamento"
          value={t.density}
          options={['compact', 'regular', 'comfy']}
          onChange={(v) => setTweak('density', v)}
        />

        <TweakSection label="Fonte display" />
        <TweakSelect
          label="Família"
          value={t.displayFont}
          options={['Spectral', 'Newsreader', 'Onest']}
          onChange={(v) => setTweak('displayFont', v)}
        />
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
