// ds-icons.jsx — Inline SVG icon set for the Lumers Flow design system.
// Hairline stroke (1.6), rounded caps, geometric — pairs with Spectral/Onest.

const Icon = ({ d, size = 18, stroke = 1.6, fill = false, children, ...rest }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill ? "currentColor" : "none"}
       stroke="currentColor" strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" {...rest}>
    {d ? <path d={d} /> : children}
  </svg>
);

const Icons = {
  Dashboard: (p) => <Icon {...p}><rect x="3" y="3"  width="8" height="9" rx="2"/><rect x="13" y="3" width="8" height="5" rx="2"/><rect x="13" y="10" width="8" height="11" rx="2"/><rect x="3" y="14" width="8" height="7" rx="2"/></Icon>,
  Invoice:   (p) => <Icon {...p}><path d="M6 3h9l4 4v14a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z"/><path d="M14 3v5h5"/><path d="M9 13h6M9 17h4"/></Icon>,
  Sun:       (p) => <Icon {...p}><circle cx="12" cy="12" r="3.5"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.5 5.5l1.4 1.4M17.1 17.1l1.4 1.4M5.5 18.5l1.4-1.4M17.1 6.9l1.4-1.4"/></Icon>,
  Wallet:    (p) => <Icon {...p}><rect x="3" y="6" width="18" height="14" rx="2.5"/><path d="M3 10h18"/><circle cx="16" cy="14" r="1.2" fill="currentColor"/></Icon>,
  TrendUp:   (p) => <Icon {...p}><path d="M4 17l5-5 4 4 7-8"/><path d="M14 8h6v6"/></Icon>,
  TrendDown: (p) => <Icon {...p}><path d="M4 7l5 5 4-4 7 8"/><path d="M14 16h6v-6"/></Icon>,
  Tag:       (p) => <Icon {...p}><path d="M3 12V4a1 1 0 0 1 1-1h8l9 9-9 9-9-9Z"/><circle cx="8" cy="8" r="1.4" fill="currentColor"/></Icon>,
  Repeat:    (p) => <Icon {...p}><path d="M4 9V7a2 2 0 0 1 2-2h11l-2-2"/><path d="M20 15v2a2 2 0 0 1-2 2H7l2 2"/></Icon>,
  Layers:    (p) => <Icon {...p}><path d="M12 3 2 8l10 5 10-5-10-5Z"/><path d="m2 13 10 5 10-5"/><path d="m2 18 10 5 10-5"/></Icon>,
  Target:    (p) => <Icon {...p}><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.2" fill="currentColor"/></Icon>,
  Chart:     (p) => <Icon {...p}><path d="M3 21h18"/><rect x="5" y="11" width="3" height="8" rx="1"/><rect x="11" y="7" width="3" height="12" rx="1"/><rect x="17" y="14" width="3" height="5" rx="1"/></Icon>,
  Download:  (p) => <Icon {...p}><path d="M12 4v11"/><path d="m7 11 5 5 5-5"/><path d="M5 20h14"/></Icon>,
  Settings:  (p) => <Icon {...p}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.8-.3 1.6 1.6 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.6 1.6 0 0 0-1-1.5 1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.8 1.6 1.6 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.8.3h.1a1.6 1.6 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8v.1a1.6 1.6 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1Z"/></Icon>,
  Users:     (p) => <Icon {...p}><circle cx="9" cy="8" r="3.5"/><path d="M2 21a7 7 0 0 1 14 0"/><path d="M16 4a3.5 3.5 0 0 1 0 7"/><path d="M18 21a7 7 0 0 0-3-5.7"/></Icon>,
  Upload:    (p) => <Icon {...p}><path d="M12 20V9"/><path d="m7 13 5-5 5 5"/><path d="M5 4h14"/></Icon>,
  Plus:      (p) => <Icon {...p}><path d="M12 5v14M5 12h14"/></Icon>,
  Search:    (p) => <Icon {...p}><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></Icon>,
  Bell:      (p) => <Icon {...p}><path d="M6 8a6 6 0 1 1 12 0v5l2 3H4l2-3V8Z"/><path d="M10 19a2 2 0 0 0 4 0"/></Icon>,
  ChevronL:  (p) => <Icon {...p}><path d="m15 6-6 6 6 6"/></Icon>,
  ChevronR:  (p) => <Icon {...p}><path d="m9 6 6 6-6 6"/></Icon>,
  ChevronD:  (p) => <Icon {...p}><path d="m6 9 6 6 6-6"/></Icon>,
  Check:     (p) => <Icon {...p}><path d="m5 12 5 5L20 7"/></Icon>,
  Calendar:  (p) => <Icon {...p}><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></Icon>,
  Filter:    (p) => <Icon {...p}><path d="M3 5h18l-7 9v5l-4 2v-7L3 5Z"/></Icon>,
  Eye:       (p) => <Icon {...p}><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></Icon>,
  Logout:    (p) => <Icon {...p}><path d="M14 3h5a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1h-5"/><path d="M9 12h11"/><path d="m13 8-4 4 4 4"/></Icon>,
  Sparkle:   (p) => <Icon {...p}><path d="M12 3v6M12 15v6M3 12h6M15 12h6M6 6l3 3M15 15l3 3M6 18l3-3M15 9l3-3"/></Icon>,
  Light:     (p) => <Icon {...p} stroke={1.4}><path d="M12 3v3M5.5 6 7 7.5M18.5 6 17 7.5M12 22a6 6 0 0 0 6-6c0-3-2-5-3-6.5S12 8 12 8s-2 .5-3 1.5S6 13 6 16a6 6 0 0 0 6 6Z"/></Icon>,
  Arrow:     (p) => <Icon {...p}><path d="M5 12h14M13 5l7 7-7 7"/></Icon>,
  Grip:      (p) => <Icon {...p}><circle cx="9" cy="6" r="1.2" fill="currentColor"/><circle cx="15" cy="6" r="1.2" fill="currentColor"/><circle cx="9" cy="12" r="1.2" fill="currentColor"/><circle cx="15" cy="12" r="1.2" fill="currentColor"/><circle cx="9" cy="18" r="1.2" fill="currentColor"/><circle cx="15" cy="18" r="1.2" fill="currentColor"/></Icon>,
};

window.Icon = Icon;
window.Icons = Icons;
