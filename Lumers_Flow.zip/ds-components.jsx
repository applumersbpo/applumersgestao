// ds-components.jsx — component reference: Buttons, Inputs, Badges, KPI cards, Progress, List rows, Insight banner

function ComponentsSection() {
  return (
    <section id="components">
      <div className="shell">
        <div className="sec-label">05 · Componentes</div>
        <h2>Peças do sistema, prontas pra montar.</h2>
        <p className="sec-intro">
          Cada componente carrega seu estado natural (hover, foco, desabilitado) e foi pensado para
          a densidade de dashboards financeiros — onde linhas pequenas e legibilidade não negociam.
        </p>

        <ButtonsBlock />
        <InputsBlock />
        <BadgesBlock />
        <CardsBlock />
        <ChartsBlock />
        <ListBlock />
      </div>
    </section>
  );
}

function SubHeading({ idx, title, desc }) {
  return (
    <div style={{ marginTop: 48, marginBottom: 20 }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 12 }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-soft)' }}>0{idx}</span>
        <h3 style={{ fontSize: 22, fontWeight: 500 }}>{title}</h3>
      </div>
      {desc && <p style={{ fontSize: 14, color: 'var(--text-muted)', marginTop: 6, maxWidth: '60ch' }}>{desc}</p>}
    </div>
  );
}

function ButtonsBlock() {
  return (
    <div>
      <SubHeading idx={1} title="Botões"
        desc="Um primário por tela. O acento mostarda fica para CTAs principais (ex.: salvar, lançar). Ghost para ações secundárias inline; danger para destruição." />
      <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, alignItems: 'center' }}>
          <button className="btn btn-primary"><Icons.Plus size={14} /> Lançar receita</button>
          <button className="btn btn-accent">Salvar alterações</button>
          <button className="btn btn-secondary">Cancelar</button>
          <button className="btn btn-ghost"><Icons.Download size={14} /> Exportar</button>
          <button className="btn btn-danger"><Icons.Logout size={14} /> Excluir</button>
          <button className="btn btn-primary" disabled>Desabilitado</button>
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, alignItems: 'center', paddingTop: 14, borderTop: '1px dashed var(--border)' }}>
          <button className="btn btn-primary lg">Criar conta</button>
          <button className="btn btn-primary">Botão padrão</button>
          <button className="btn btn-primary sm">Compacto</button>
          <span style={{ marginLeft: 12, fontSize: 12.5, color: 'var(--text-soft)' }}>Tamanhos · lg / md / sm</span>
        </div>
      </div>
    </div>
  );
}

function InputsBlock() {
  return (
    <div>
      <SubHeading idx={2} title="Inputs e formulários"
        desc="Labels acima do campo, foco com anel verde suave, mensagens de erro em terroso. Sempre acompanhe valores monetários do prefixo R$." />
      <div className="card grid cols-2" style={{ rowGap: 24, columnGap: 28 }}>
        <div className="field">
          <label>E-mail</label>
          <input className="input" placeholder="seu@email.com" defaultValue="ana@lumers.com.br" />
        </div>
        <div className="field">
          <label>Valor</label>
          <div style={{ position: 'relative' }}>
            <span style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-soft)', fontSize: 13 }}>R$</span>
            <input className="input" defaultValue="1.250,00" style={{ paddingLeft: 36, fontVariantNumeric: 'tabular-nums' }} />
          </div>
        </div>
        <div className="field">
          <label>Categoria</label>
          <select className="select">
            <option>Marketing & publicidade</option>
            <option>Fornecedores</option>
            <option>Folha</option>
          </select>
        </div>
        <div className="field">
          <label>Data de vencimento</label>
          <div style={{ position: 'relative' }}>
            <Icons.Calendar size={15} style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-soft)' }} />
            <input className="input" defaultValue="28/05/2026" />
          </div>
        </div>
        <div className="field" style={{ gridColumn: 'span 2' }}>
          <label>Descrição</label>
          <textarea className="textarea" rows={3} placeholder="Anote o contexto deste lançamento..." />
        </div>
        <div className="field">
          <label>Campo com erro</label>
          <input className="input" defaultValue="abc" style={{ borderColor: 'var(--expense-500)', boxShadow: '0 0 0 4px rgba(201,90,71,.12)' }} />
          <span style={{ fontSize: 12, color: 'var(--expense-700)', display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ width: 14, height: 14, borderRadius: '50%', background: 'var(--expense-500)', color: 'white', display: 'grid', placeItems: 'center', fontSize: 9, fontWeight: 700 }}>!</span>
            Informe um e-mail válido
          </span>
        </div>
        <div className="field">
          <label>Campo desabilitado</label>
          <input className="input" defaultValue="Não editável" disabled style={{ background: 'var(--bg-subtle)', color: 'var(--text-soft)' }} />
        </div>
      </div>
    </div>
  );
}

function BadgesBlock() {
  return (
    <div>
      <SubHeading idx={3} title="Badges, status, tags"
        desc="Pílulas curtas com cor de fundo suave. O ponto em currentColor reforça o status quando o badge precisa ser lido rápido." />
      <div className="card" style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
        <span className="badge income"><span className="dot" />Pago</span>
        <span className="badge expense"><span className="dot" />Atrasado</span>
        <span className="badge warn"><span className="dot" />Vence em 3 dias</span>
        <span className="badge info"><span className="dot" />Em análise</span>
        <span className="badge">Rascunho</span>
        <span className="badge"><Icons.Repeat size={11} />Recorrente</span>
        <span className="badge"><Icons.Tag size={11} />Marketing</span>
        <span className="badge income"><Icons.Check size={11} />Conciliado</span>
      </div>
    </div>
  );
}

function CardsBlock() {
  return (
    <div>
      <SubHeading idx={4} title="KPI cards"
        desc="O card de número é o tijolo do dashboard. Ícone tonal à esquerda dá leitura instantânea da semântica; o valor usa Spectral pra ter presença sem precisar de tamanho enorme." />
      <div className="grid cols-4">
        <Kpi tone="income"  label="Faturamento"   value="R$ 48.320" delta="+12% vs. mês passado" deltaTone="income"
             icon={<Icons.TrendUp />} progress={68} progressLabel="68% da meta" />
        <Kpi tone="expense" label="Contas a pagar" value="R$ 22.180" delta="R$ 8.4k vencendo em 7 dias" deltaTone="warn"
             icon={<Icons.TrendDown />} progress={32} progressTone="expense" progressLabel="32% pago" />
        <Kpi tone="info"    label="Saldo projetado" value="R$ 26.140" delta="Receita prevista – todas as saídas"
             icon={<Icons.Wallet />} sparkData={[4,6,5,7,9,8,11,12,10,14]} />
        <Kpi tone="warn"    label="Saldo real"      value="R$ 18.700" delta="Recebido – o que saiu"
             icon={<Icons.Sun />} />
      </div>
    </div>
  );
}

function Kpi({ tone='info', label, value, delta, deltaTone, icon, progress, progressTone, progressLabel, sparkData }) {
  return (
    <div className="kpi">
      <div className="top">
        <div>
          <span className="label">{label}</span>
          <div className={"value " + (tone === 'income' || tone === 'expense' ? tone : '')} style={{ marginTop: 6 }}>{value}</div>
        </div>
        <div className={"ico-tile " + tone}>{icon}</div>
      </div>
      {progress != null && (
        <div>
          <div className={"progress " + (progressTone || tone)}>
            <span style={{ width: progress + '%' }} />
          </div>
          <div className="footnote" style={{ marginTop: 8 }}>
            <span>{progressLabel}</span>
          </div>
        </div>
      )}
      {sparkData && (
        <div className="spark income">
          {sparkData.map((v,i) => {
            const peak = v === Math.max(...sparkData);
            return <span key={i} className={peak ? 'peak' : ''} style={{ height: v * 2 + 'px' }} />;
          })}
        </div>
      )}
      {!progress && !sparkData && delta && (
        <div className="footnote">{delta}</div>
      )}
      {progress != null && delta && (
        <div className="footnote">
          {deltaTone === 'income' && <span style={{ color: 'var(--income-600)' }}>▲</span>}
          {deltaTone === 'warn' && <span style={{ color: 'var(--warn-600)' }}>●</span>}
          {delta}
        </div>
      )}
    </div>
  );
}

function ChartsBlock() {
  return (
    <div>
      <SubHeading idx={5} title="Padrões para gráficos"
        desc="Eixos discretos, barra/área em duas tonalidades por série, grade em neutral-200. Receita = primary; despesa = expense suave; previsto = tracejado." />
      <div className="grid cols-2">
        <div className="card" style={{ padding: 24 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <div>
              <h4 style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 500 }}>Fluxo de caixa · últimos 12 meses</h4>
              <div style={{ fontSize: 12.5, color: 'var(--text-soft)', marginTop: 2 }}>Receita vs. despesa, valores mensais</div>
            </div>
            <div style={{ display: 'flex', gap: 12, fontSize: 11.5, color: 'var(--text-muted)' }}>
              <span style={{ display:'flex', alignItems:'center', gap:6 }}>
                <span style={{ width:10, height:10, background:'var(--primary-600)', borderRadius:2 }}/> Receita
              </span>
              <span style={{ display:'flex', alignItems:'center', gap:6 }}>
                <span style={{ width:10, height:10, background:'var(--expense-500)', borderRadius:2, opacity:.7 }}/> Despesa
              </span>
            </div>
          </div>
          <CashflowChart />
        </div>

        <div className="card" style={{ padding: 24 }}>
          <div>
            <h4 style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 500 }}>Despesas por categoria · maio</h4>
            <div style={{ fontSize: 12.5, color: 'var(--text-soft)', marginTop: 2 }}>Distribuição do total saído</div>
          </div>
          <CategoryDonut />
        </div>
      </div>
    </div>
  );
}

function CashflowChart() {
  const months = ['Jun','Jul','Ago','Set','Out','Nov','Dez','Jan','Fev','Mar','Abr','Mai'];
  const income  = [32,34,38,40,36,42,46,48,44,50,52,55];
  const expense = [22,28,24,30,26,28,32,30,28,34,30,38];
  const max = 60;
  return (
    <div style={{ marginTop: 18 }}>
      <svg viewBox="0 0 480 200" style={{ width: '100%', height: 200 }}>
        {[0,15,30,45,60].map((v,i) => (
          <g key={i}>
            <line x1="32" y1={180 - (v/max)*160} x2="480" y2={180 - (v/max)*160} stroke="var(--border)" strokeDasharray="2 3" />
            <text x="0" y={184 - (v/max)*160} fontSize="9" fill="var(--text-soft)" fontFamily="var(--font-mono)">{v}k</text>
          </g>
        ))}
        {months.map((m,i) => {
          const x = 40 + i*37;
          return (
            <g key={i}>
              <rect x={x}    y={180 - (income[i]/max)*160}  width="11" height={(income[i]/max)*160}  rx="2" fill="var(--primary-600)" />
              <rect x={x+13} y={180 - (expense[i]/max)*160} width="11" height={(expense[i]/max)*160} rx="2" fill="var(--expense-500)" opacity="0.7" />
              <text x={x+12} y="195" fontSize="9" fill="var(--text-soft)" textAnchor="middle">{m}</text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}

function CategoryDonut() {
  const data = [
    { label: 'Fornecedores',   value: 38, color: 'var(--primary-600)' },
    { label: 'Folha',          value: 24, color: 'var(--brand-teal)' },
    { label: 'Marketing',      value: 14, color: 'var(--brand-mustard)' },
    { label: 'Infraestrutura', value: 12, color: 'var(--brand-teal-soft)' },
    { label: 'Outros',         value: 12, color: 'var(--neutral-300)' },
  ];
  const total = data.reduce((s,d) => s + d.value, 0);
  let acc = 0;
  const C = 2 * Math.PI * 60;
  return (
    <div style={{ marginTop: 18, display: 'grid', gridTemplateColumns: '180px 1fr', gap: 24, alignItems: 'center' }}>
      <svg viewBox="0 0 180 180" style={{ width: 180, height: 180 }}>
        <circle cx="90" cy="90" r="60" fill="none" stroke="var(--neutral-100)" strokeWidth="22" />
        {data.map((d, i) => {
          const len = (d.value / total) * C;
          const dasharray = `${len} ${C}`;
          const dashoffset = -((acc / total) * C);
          acc += d.value;
          return <circle key={i} cx="90" cy="90" r="60" fill="none" stroke={d.color} strokeWidth="22"
                          strokeDasharray={dasharray} strokeDashoffset={dashoffset} transform="rotate(-90 90 90)" />;
        })}
        <text x="90" y="86" textAnchor="middle" fontSize="11" fill="var(--text-soft)" fontFamily="var(--font-sans)">Total</text>
        <text x="90" y="106" textAnchor="middle" fontSize="20" fill="var(--text)" fontFamily="var(--font-display)" fontWeight="500">R$ 22,1k</text>
      </svg>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {data.map((d,i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 13 }}>
            <span style={{ width: 10, height: 10, background: d.color, borderRadius: 2 }} />
            <span style={{ flex: 1 }}>{d.label}</span>
            <b style={{ fontFamily: 'var(--font-display)', fontWeight: 500 }}>{d.value}%</b>
          </div>
        ))}
      </div>
    </div>
  );
}

function ListBlock() {
  return (
    <div>
      <SubHeading idx={6} title="Listas, linhas e insights"
        desc="Padrão para 'Últimas movimentações', extratos e tabelas de contas. Avatar tonal à esquerda, valor monetário com cor semântica." />
      <div className="grid cols-2">
        <div className="card" style={{ padding: 0 }}>
          <div style={{ padding: '16px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <h4 style={{ fontFamily: 'var(--font-display)', fontSize: 17, fontWeight: 500 }}>Últimas movimentações</h4>
            <a href="#" style={{ fontSize: 12.5, color: 'var(--primary-700)' }}>Ver tudo →</a>
          </div>
          <div>
            <Row tone="income"  who="Cliente · Studio Pílula" sub="Recebido · 24/05" badge={{tone:'income', text:'Pago'}} amount="+ R$ 2.480,00" amountTone="income" />
            <Row tone="expense" who="Aluguel sala · Maio"    sub="Vence em 3 dias"  badge={{tone:'warn',   text:'A vencer'}} amount="− R$ 3.200,00" amountTone="expense" />
            <Row tone="info"    who="Assinatura · Notion"    sub="Recorrente · 28/05" badge={{tone:'info',  text:'Recorrente'}} amount="− R$ 96,00"     amountTone="expense" />
            <Row tone="expense" who="Fornecedor · Tipograf"  sub="Atrasado há 2 dias" badge={{tone:'expense', text:'Atrasado'}} amount="− R$ 540,00"    amountTone="expense" />
            <Row tone="income"  who="Cliente · Casa Verão"   sub="Recebido · 22/05"   badge={{tone:'income', text:'Pago'}}    amount="+ R$ 1.250,00"  amountTone="income" />
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div className="insight income">
            <div className="ico-tile"><Icons.TrendUp size={16} /></div>
            <div className="body">
              <b>Você está 12% acima da meta neste mês.</b>
              <p>Restam 7 dias para o fechamento. No ritmo atual, deve chegar a R$ 52.400 — mantenha a régua de cobrança aberta.</p>
            </div>
          </div>
          <div className="insight">
            <div className="ico-tile"><Icons.Bell size={16} /></div>
            <div className="body">
              <b>3 contas vencem nos próximos 5 dias.</b>
              <p>Total de R$ 8.420,00. <a href="#">Programar pagamento →</a></p>
            </div>
          </div>
          <div className="card" style={{ padding: 22 }}>
            <div className="label-mini" style={{ marginBottom: 10 }}>Meta de faturamento · maio</div>
            <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 12 }}>
              <span style={{ fontFamily: 'var(--font-display)', fontSize: 30, fontWeight: 500 }}>R$ 48.320</span>
              <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>de R$ 70.000</span>
            </div>
            <div className="progress income"><span style={{ width: '69%' }}/></div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 10, fontSize: 12, color: 'var(--text-soft)' }}>
              <span>69% concluído</span><span>21 dias úteis · 7 restantes</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Row({ tone, who, sub, badge, amount, amountTone }) {
  return (
    <div className="row">
      <div className={"avatar " + tone}>{ tone === 'income' ? '↑' : tone === 'expense' ? '↓' : '↻' }</div>
      <div className="who"><b>{who}</b><span>{sub}</span></div>
      <span className={"badge " + badge.tone}><span className="dot"/>{badge.text}</span>
      <span className={"amount " + amountTone}>{amount}</span>
    </div>
  );
}

Object.assign(window, { ComponentsSection });
